"""
Some example strategies for people who want to create a custom, homemade bot.

With these classes, bot makers will not have to implement the UCI or XBoard interfaces themselves.
"""

from __future__ import annotations

from abc import ABC
from math import inf
import chess
import time
from chess.engine import PlayResult
import chess.polyglot
import random
from lib.engine_wrapper import MinimalEngine
from typing import Any, Union
import logging
import numpy as np
from enum import Enum

MOVE = Union[chess.engine.PlayResult, list[chess.Move]]

# Use this logger variable to print messages to the console or log files.
# logger.info("message") will always print "message" to the console or log file.
# logger.debug("message") will only print "message" if verbose logging is enabled.
logger = logging.getLogger(__name__)


class ExampleEngine(MinimalEngine, ABC):
    """An example engine that all homemade engines inherit."""

    pass


# Strategy names and ideas from tom7's excellent eloWorld video

class RandomMove(ExampleEngine):
    """Get a random move."""

    def search(self, board: chess.Board, *args: Any) -> PlayResult:
        """Choose a random move."""
        return PlayResult(random.choice(list(board.legal_moves)), None)


# Enum class that contains description for each possible positional value of the piece on the table
class FigurePositionValue(Enum):
    pawn_position_value = lambda: np.array([
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0],
        [1.0, 1.0, 2.0, 3.0, 3.0, 2.0, 1.0, 1.0],
        [0.5, 0.5, 1.0, 2.5, 2.5, 1.0, 0.5, 0.5],
        [0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0],
        [0.5, -0.5, -1.0, 0.0, 0.0, -1.0, -0.5, 0.5],
        [0.5, 1.0, 1.0, -2.0, -2.0, 1.0, 1.0, 0.5],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    ])

    knight_position_value = lambda: np.array([
        [-5.0, -4.0, -3.0, -3.0, -3.0, -3.0, -4.0, -5.0],
        [-4.0, -2.0, 0.0, 0.0, 0.0, 0.0, -2.0, -4.0],
        [-3.0, 0.0, 1.0, 1.5, 1.5, 1.0, 0.0, -3.0],
        [-3.0, 0.5, 1.5, 2.0, 2.0, 1.5, 0.5, -3.0],
        [-3.0, 0.0, 1.5, 2.0, 2.0, 1.5, 0.0, -3.0],
        [-3.0, 0.5, 1.0, 1.5, 1.5, 1.0, 0.5, -3.0],
        [-4.0, -2.0, 0.0, 0.5, 0.5, 0.0, -2.0, -4.0],
        [-5.0, -4.0, -3.0, -3.0, -3.0, -3.0, -4.0, -5.0]
    ])

    bishop_position_value = lambda: np.array([
        [-2.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -2.0],
        [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0],
        [-1.0, 0.0, 0.5, 1.0, 1.0, 0.5, 0.0, -1.0],
        [-1.0, 0.5, 0.5, 1.0, 1.0, 0.5, 0.5, -1.0],
        [-1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, -1.0],
        [-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0],
        [-1.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.5, -1.0],
        [-2.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -2.0]
    ])

    rook_position_value = lambda: np.array([
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5],
        [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
        [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
        [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
        [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
        [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
        [0.0, 0.0, 0.0, 0.5, 0.5, 0.0, 0.0, 0.0]
    ])

    queen_position_value = lambda: np.array([
        [-2.0, -1.0, -1.0, -0.5, -0.5, -1.0, -1.0, -2.0],
        [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0],
        [-1.0, 0.0, 0.5, 0.5, 0.5, 0.5, 0.0, -1.0],
        [-0.5, 0.0, 0.5, 0.5, 0.5, 0.5, 0.0, -0.5],
        [0.0, 0.0, 0.5, 0.5, 0.5, 0.5, 0.0, -0.5],
        [-1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.0, -1.0],
        [-1.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, -1.0],
        [-2.0, -1.0, -1.0, -0.5, -0.5, -1.0, -1.0, -2.0]
    ])

    king_position_value = lambda: np.array([
        [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
        [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
        [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
        [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
        [-2.0, -3.0, -3.0, -4.0, -4.0, -3.0, -3.0, -2.0],
        [-1.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -1.0],
        [2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0],
        [2.0, 3.0, 1.0, 0.0, 0.0, 1.0, 3.0, 2.0]
    ])


class MinMaxEngine(MinimalEngine):
    # main function to search the best move
    def search(self, board: chess.Board, *args: Any) -> PlayResult:
        best_move = self.use_progressive_deepening(board, max_depth=3, time_limit=20)

        return PlayResult(best_move, None)

    # function tht runs minimax algorithm according to the specified depth and type of pieces
    def find_best_move(self, board, depth):
        best_move = None
        alpha = -inf
        beta = inf
        moves_options = self.find_list_of_moves(board)
        if not moves_options:
            moves_options = board.legal_moves
        # in case bot plays with white pieces (goes first)
        if board.turn == chess.WHITE:
            best_score = -inf
            for move in moves_options:
                board.push(move)
                evaluated_score = self.run_minimax(board=board, depth=depth, alpha=alpha, beta=beta, is_maximizing_phase=False)
                board.pop()
                if evaluated_score > best_score:
                    best_move = move
                    best_score = evaluated_score
        # in case bot plays with white pieces (goes last)
        else:
            best_score = inf
            for move in moves_options:
                board.push(move)
                evaluated_score = self.run_minimax(board=board, depth=depth, alpha=alpha, beta=beta, is_maximizing_phase=True)
                board.pop()
                if evaluated_score < best_score:
                    best_move = move
                    best_score = evaluated_score
        return best_move

    # minimax function implementation (includes alpha-beta pruning)
    def run_minimax(self, board, depth, alpha, beta, is_maximizing_phase):
        # in case reached the depth 0, return the value computed for the current piece
        if depth == 0 or board.is_game_over():
            return self.evaluate_board(board)

        moves_options = self.find_list_of_moves(board)
        if not moves_options:
            moves_options = board.legal_moves
        # maximizing funtion
        if is_maximizing_phase:
            max_score = -inf
            for move in moves_options:
                board.push(move)
                latest_score = self.run_minimax(board, depth - 1, alpha, beta, False)
                max_score = max(max_score, latest_score)
                board.pop()
                alpha = max(alpha, max_score)
                # alpha-beta pruning: do not analyze further if not needed
                if alpha >= beta:
                    return max_score
            return max_score
        # minimizing part:
        else:
            min_score = inf
            for move in moves_options:
                board.push(move)
                latest_score = self.run_minimax(board, depth - 1, alpha, beta, True)
                min_score = min(min_score, latest_score)
                board.pop()
                beta = min(beta, min_score)
                # alpha-beta pruning: do not analyze further if not needed
                if alpha >= beta:
                    return min_score
            return min_score

    # define progressive deepening
    def use_progressive_deepening(self, board, max_depth, time_limit):
        current_score = -inf
        # define range of depths to use
        for depth in range(1, max_depth + 1):
            start_time = time.time()
            current_score = self.find_best_move(board=board, depth=depth)
            if time.time() - start_time >= time_limit:
                break
        return current_score

    # define functions to evaluate the board
    def evaluate_board(self, board):
        score = 0
        for square in chess.SQUARES:
            piece = board.piece_at(square)
            if piece is not None:
                # simple score evaluation based on the position of each piece
                if piece.color == chess.WHITE:
                    score += (self.get_piece_value(piece) + self.get_position_value(piece, True, chess.square_file(square), chess.square_rank(square)))
                else:
                    score -= (self.get_piece_value(piece) + self.get_position_value(piece, False, chess.square_file(square), chess.square_rank(square)))

        # evaluation of the possibility to do castling
        if board.has_kingside_castling_rights(chess.WHITE):
            score += 0.2
        if board.has_kingside_castling_rights(chess.BLACK):
            score -= 0.2

        # evaluation of king safety based on the number of safe squares round the king
        white_king_safety = sum(1 for sq in board.attacks(board.king(chess.WHITE)) if board.piece_at(sq) is None)
        black_king_safety = sum(1 for sq in board.attacks(board.king(chess.BLACK)) if board.piece_at(sq) is None)
        king_safety = white_king_safety - black_king_safety
        score += king_safety * 0.05

        return score

    # method to find the more similar patterns in an open book file and get the best possible moves
    @staticmethod
    def find_list_of_moves(board):
        with chess.polyglot.open_reader("bookfish.bin") as reader:
            move_list = []
            for entry in reader.find_all(board):
                move_list.append(entry.move)
        return move_list

    # simple definition for each piece's value
    @staticmethod
    def get_piece_value(piece):
        piece = str(piece).upper()
        if piece == "P":
            return 1
        elif piece == "N" or piece == "B":
            return 3
        elif piece == "R":
            return 5
        elif piece == "Q":
            return 9
        else:
            return 0

    # the value each piece brings according to the colour and position it is in
    @staticmethod
    def get_position_value(piece, is_self_color, row, column):
        piece = str(piece).upper()
        if piece == "P":
            return FigurePositionValue.pawn_position_value()[row, column] if is_self_color else \
                np.flip(FigurePositionValue.pawn_position_value(), axis=None)[row, column]
        elif piece == "N":
            return FigurePositionValue.knight_position_value()[row, column]
        elif piece == "B":
            return FigurePositionValue.bishop_position_value()[row, column] if is_self_color else \
                np.flip(FigurePositionValue.bishop_position_value(), axis=None)[row, column]
        elif piece == "R":
            return FigurePositionValue.rook_position_value()[row, column] if is_self_color else \
                np.flip(FigurePositionValue.rook_position_value(), axis=None)[row, column]
        elif piece == "Q":
            return FigurePositionValue.queen_position_value()[row, column]
        else:
            return FigurePositionValue.king_position_value()[row, column]


class Alphabetical(ExampleEngine):
    """Get the first move when sorted by san representation."""

    def search(self, board: chess.Board, *args: Any) -> PlayResult:
        """Choose the first move alphabetically."""
        moves = list(board.legal_moves)
        moves.sort(key=board.san)
        return PlayResult(moves[0], None)


class FirstMove(ExampleEngine):
    """Get the first move when sorted by uci representation."""

    def search(self, board: chess.Board, *args: Any) -> PlayResult:
        """Choose the first move alphabetically in uci representation."""
        moves = list(board.legal_moves)
        moves.sort(key=str)
        return PlayResult(moves[0], None)


class ComboEngine(ExampleEngine):
    """
    Get a move using multiple different methods.

    This engine demonstrates how one can use `time_limit`, `draw_offered`, and `root_moves`.
    """

    def search(self, board: chess.Board, time_limit: chess.engine.Limit, ponder: bool, draw_offered: bool,
               root_moves: MOVE) -> chess.engine.PlayResult:
        """
        Choose a move using multiple different methods.

        :param board: The current position.
        :param time_limit: Conditions for how long the engine can search (e.g. we have 10 seconds and search up to depth 10).
        :param ponder: Whether the engine can ponder after playing a move.
        :param draw_offered: Whether the bot was offered a draw.
        :param root_moves: If it is a list, the engine should only play a move that is in `root_moves`.
        :return: The move to play.
        """
        if isinstance(time_limit.time, int):
            my_time = time_limit.time
            my_inc = 0
        elif board.turn == chess.WHITE:
            my_time = time_limit.white_clock if isinstance(time_limit.white_clock, int) else 0
            my_inc = time_limit.white_inc if isinstance(time_limit.white_inc, int) else 0
        else:
            my_time = time_limit.black_clock if isinstance(time_limit.black_clock, int) else 0
            my_inc = time_limit.black_inc if isinstance(time_limit.black_inc, int) else 0

        possible_moves = root_moves if isinstance(root_moves, list) else list(board.legal_moves)

        if my_time / 60 + my_inc > 10:
            # Choose a random move.
            move = random.choice(possible_moves)
        else:
            # Choose the first move alphabetically in uci representation.
            possible_moves.sort(key=str)
            move = possible_moves[0]
        return PlayResult(move, None, draw_offered=draw_offered)