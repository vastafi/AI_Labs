"""This lib folder contains the library code necessary for running lichess-bot."""
